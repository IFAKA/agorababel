import { useState } from 'react';
import { LandingScreen } from './components/LandingScreen';
import { ProcessingScreen } from './components/ProcessingScreen';
import { MarketScreen } from './components/MarketScreen';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<'landing' | 'processing' | 'market'>('landing');

  const handleNavigate = (screen: 'landing' | 'processing' | 'market') => {
    setCurrentScreen(screen);
  };

  return (
    <div className="w-[1440px] h-[900px] mx-auto overflow-hidden bg-[#1A1A1C] border border-[#333336] shadow-2xl">
      {currentScreen === 'landing' && <LandingScreen onNavigate={handleNavigate} />}
      {currentScreen === 'processing' && <ProcessingScreen onNavigate={handleNavigate} />}
      {currentScreen === 'market' && <MarketScreen onNavigate={handleNavigate} />}
    </div>
  );
}