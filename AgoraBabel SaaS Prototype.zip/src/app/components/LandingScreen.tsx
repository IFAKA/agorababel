export function LandingScreen({ onNavigate }: { onNavigate: (screen: string) => void }) {
  return (
    <div className="w-full h-full bg-[#1A1A1C] text-[#D4D4D0] overflow-hidden flex flex-col">
      {/* Header */}
      <header className="border-b border-[#333336] px-8 py-4 flex-shrink-0">
        <div className="flex items-center justify-between">
          <h1 className="font-serif text-lg tracking-tight text-[#B0A090]">AgoraBabel</h1>
          <div className="flex items-center gap-6 text-[10px] text-[#7A7A76] uppercase tracking-wider">
            <span>Intelligence</span>
            <span>Orchestration</span>
            <span>Settlement</span>
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="flex-1 overflow-y-auto">
        <div className="max-w-5xl mx-auto px-8 py-20">
          {/* Title Section */}
          <div className="mb-20">
            <h2 className="font-serif text-4xl text-[#D4D4D0] mb-4 tracking-tight leading-tight max-w-3xl">
              Autonomous Market Intelligence <br/>from Global Signal
            </h2>
            <p className="text-sm text-[#9A9A96] max-w-2xl leading-relaxed">
              Multi-agent systems ingest non-English news sources, synthesize resolvable prediction markets, and commit cryptographic reasoning traces to permanent settlement infrastructure.
            </p>
          </div>

          {/* Input Section */}
          <div className="grid grid-cols-[1fr_280px] gap-8 mb-12">
            {/* Main Input */}
            <div className="bg-[#242426] border border-[#333336] p-8">
              <label className="block text-[9px] text-[#7A7A76] mb-4 uppercase tracking-widest">
                Source Material
              </label>
              <textarea
                className="w-full h-72 bg-[#1A1A1C] border border-[#333336] px-4 py-3 text-xs text-[#D4D4D0] placeholder:text-[#7A7A76] resize-none focus:outline-none focus:border-[#8B7355] transition-colors font-mono leading-relaxed"
                placeholder="Paste article URL, news excerpt, or local-market signal in Spanish, Chinese, Portuguese, Arabic, or other non-English languages..."
              />
              <div className="mt-6 flex items-center justify-between">
                <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest">
                  Multi-agent validation • Arc settlement
                </div>
                <button
                  onClick={() => onNavigate('processing')}
                  className="bg-[#8B7355] text-[#1A1A1C] px-6 py-2 text-[10px] uppercase tracking-widest hover:bg-[#9A8365] transition-colors"
                >
                  Initiate Pipeline
                </button>
              </div>
            </div>

            {/* Pipeline Overview */}
            <div className="bg-[#242426] border border-[#333336] p-6">
              <div className="text-[9px] text-[#7A7A76] mb-4 uppercase tracking-widest">Process</div>
              <div className="space-y-2">
                {[
                  'Signal ingestion',
                  'Translation synthesis',
                  'Market generation',
                  'Critic validation',
                  'Trace commitment',
                  'Reward distribution',
                ].map((step, idx) => (
                  <div key={idx} className="flex items-center gap-3 py-2 border-b border-[#333336]/50 last:border-0">
                    <div className="w-4 h-4 border border-[#333336] flex items-center justify-center text-[9px] text-[#7A7A76] flex-shrink-0">
                      {idx + 1}
                    </div>
                    <span className="text-[10px] text-[#9A9A96]">{step}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* System Metrics */}
          <div className="border-t border-[#333336] pt-8">
            <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest mb-6">System Metrics</div>
            <div className="grid grid-cols-4 gap-6">
              <div className="bg-[#242426] border border-[#333336] p-5">
                <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest mb-2">Markets Generated</div>
                <div className="text-3xl font-serif text-[#D4D4D0]">128</div>
              </div>
              <div className="bg-[#242426] border border-[#333336] p-5">
                <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest mb-2">Critic Acceptance</div>
                <div className="text-3xl font-serif text-[#7A9178]">74%</div>
              </div>
              <div className="bg-[#242426] border border-[#333336] p-5">
                <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest mb-2">Trace Commits</div>
                <div className="text-3xl font-serif text-[#D4D4D0]">311</div>
              </div>
              <div className="bg-[#242426] border border-[#333336] p-5">
                <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest mb-2">Rewards Distributed</div>
                <div className="text-3xl font-serif text-[#8B7355]">94.2</div>
                <div className="text-[9px] text-[#7A7A76] mt-1">USDC</div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
