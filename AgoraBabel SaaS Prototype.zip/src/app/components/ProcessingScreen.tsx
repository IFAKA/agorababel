export function ProcessingScreen({ onNavigate }: { onNavigate: (screen: string) => void }) {
  return (
    <div className="w-full h-full bg-[#1A1A1C] text-[#D4D4D0] overflow-hidden flex flex-col">
      {/* Header */}
      <header className="border-b border-[#333336] px-8 py-4 flex-shrink-0">
        <div className="flex items-center justify-between">
          <h1
            className="font-serif text-lg tracking-tight cursor-pointer text-[#B0A090]"
            onClick={() => onNavigate('landing')}
          >
            AgoraBabel
          </h1>
          <div className="flex items-center gap-6 text-[10px] text-[#7A7A76] uppercase tracking-wider">
            <span>Intelligence</span>
            <span className="text-[#8B7355]">Orchestration</span>
            <span>Settlement</span>
          </div>
        </div>
      </header>

      {/* Main 3-Column Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* LEFT COLUMN: Intelligence Dossier */}
        <aside className="w-[280px] border-r border-[#333336] bg-[#242426] p-6 overflow-y-auto flex-shrink-0">
          <div className="space-y-6">
            {/* Dossier Header */}
            <div className="border-b border-[#333336] pb-4">
              <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest mb-2">Signal Detected</div>
              <div className="text-xs text-[#B0A090] leading-relaxed font-serif">
                Argentina Currency Controls
              </div>
            </div>

            {/* Source Intelligence */}
            <div className="space-y-3">
              <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest mb-3">Source Intelligence</div>

              <div className="space-y-2 text-[11px]">
                <div className="flex justify-between py-1 border-b border-[#333336]/50">
                  <span className="text-[#7A7A76]">Source</span>
                  <span className="text-[#9A9A96]">La Nación</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#333336]/50">
                  <span className="text-[#7A7A76]">Country</span>
                  <span className="text-[#9A9A96]">Argentina</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#333336]/50">
                  <span className="text-[#7A7A76]">Language</span>
                  <span className="text-[#9A9A96]">Spanish</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#333336]/50">
                  <span className="text-[#7A7A76]">Category</span>
                  <span className="text-[#9A9A96]">Macro / FX</span>
                </div>
              </div>
            </div>

            {/* Detected Entities */}
            <div className="space-y-3">
              <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest">Entities</div>
              <div className="flex flex-wrap gap-1.5">
                {['Central Bank', 'Currency Controls', 'Government Decree', 'Milei Administration'].map((entity) => (
                  <span key={entity} className="text-[10px] px-2 py-1 bg-[#2A2A2C] border border-[#333336] text-[#9A9A96]">
                    {entity}
                  </span>
                ))}
              </div>
            </div>

            {/* Geopolitical Context */}
            <div className="space-y-3">
              <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest">Context</div>
              <div className="text-[10px] text-[#9A9A96] leading-relaxed">
                Signals institutional shift in Argentine monetary policy. Potential market-moving event with verifiable resolution criteria.
              </div>
            </div>

            {/* Timestamp */}
            <div className="pt-4 border-t border-[#333336]">
              <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest mb-1">Ingested</div>
              <div className="text-[10px] text-[#9A9A96] font-mono">2026-05-14 18:42:17 UTC</div>
            </div>
          </div>
        </aside>

        {/* CENTER COLUMN: Multi-Agent Reasoning System */}
        <main className="flex-1 overflow-y-auto bg-[#1A1A1C] p-8">
          <div className="max-w-3xl">
            <div className="mb-6">
              <h2 className="font-serif text-xl text-[#D4D4D0] mb-1">Autonomous Deliberation</h2>
              <p className="text-[10px] text-[#7A7A76] uppercase tracking-widest">Multi-agent market synthesis</p>
            </div>

            {/* Agent Reasoning Flow */}
            <div className="space-y-0">
              {/* Ingestion Agent */}
              <AgentBlock
                title="Ingestion Agent"
                status="validated"
                confidence={92}
                timestamp="18:42:18"
                reasoning="Source verified. Language identified as Spanish (Argentina). Extracted 4 core entities. Signal categorized as macro-financial with institutional source credibility."
              />

              {/* Translator Agent */}
              <AgentBlock
                title="Translator Agent"
                status="validated"
                confidence={88}
                timestamp="18:42:19"
                reasoning="Local-market terminology mapped to standard financial lexicon. 'Cepo cambiario' translated as 'currency controls' with contextual precision. Market-relevant framing established."
              />

              {/* Market Generator */}
              <AgentBlock
                title="Market Generator"
                status="validated"
                confidence={76}
                timestamp="18:42:21"
                reasoning="Binary question synthesized. Resolution criteria anchored to official government decree or central bank publication. Deadline set to July 1, 2026 based on institutional timeline analysis."
              />

              {/* Critic Agent */}
              <AgentBlock
                title="Critic Agent"
                status="processing"
                confidence={84}
                timestamp="18:42:22"
                reasoning="Ambiguity analysis in progress. Verifying resolution source objectivity. Deadline feasibility confirmed. Preliminary assessment: market structurally sound."
              />

              {/* Arc Settlement */}
              <AgentBlock
                title="Arc Settlement"
                status="awaiting"
                confidence={null}
                timestamp={null}
                reasoning="Trace hash generation complete. Awaiting critic validation to initiate permanent commitment to Arc ledger."
              />
            </div>
          </div>
        </main>

        {/* RIGHT COLUMN: Settlement & Trace Layer */}
        <aside className="w-[320px] border-l border-[#333336] bg-[#242426] overflow-y-auto flex-shrink-0">
          <div className="p-6 space-y-6">
            {/* Settlement Header */}
            <div className="border-b border-[#333336] pb-4">
              <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest mb-2">Cryptographic Archive</div>
              <div className="text-xs text-[#B0A090] font-serif">Reasoning Trace</div>
            </div>

            {/* Trace Hash */}
            <div className="bg-[#2A2A2C] border border-[#333336] p-4">
              <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest mb-2">Trace Hash</div>
              <div className="text-[11px] text-[#D4D4D0] font-mono break-all leading-relaxed">
                0x9f2a8c1b4e7d<br/>3a5f6c9e2b8d<br/>7f4a1c6e9b3d<br/>2a8f5c1e7b81bd
              </div>
            </div>

            {/* Arc Transaction */}
            <div className="space-y-3">
              <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest">Arc Settlement</div>

              <div className="space-y-2 text-[11px]">
                <div className="flex justify-between py-1.5 border-b border-[#333336]/50">
                  <span className="text-[#7A7A76]">Network</span>
                  <span className="text-[#9A9A96]">Arc Testnet</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-[#333336]/50">
                  <span className="text-[#7A7A76]">Status</span>
                  <span className="text-[#6B8E9F] flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-[#6B8E9F] rounded-full animate-pulse" />
                    Pending
                  </span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-[#333336]/50">
                  <span className="text-[#7A7A76]">Finality</span>
                  <span className="text-[#9A9A96]">&lt;1s</span>
                </div>
              </div>
            </div>

            {/* Reward Pool - Ceremonial */}
            <div className="bg-[#2A2A2C] border border-[#8B7355]/20 p-4">
              <div className="text-[9px] text-[#8B7355] uppercase tracking-widest mb-3">Reward Pool</div>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl text-[#D4D4D0] font-serif">1.25</span>
                <span className="text-xs text-[#7A7A76]">USDC</span>
              </div>
              <div className="text-[9px] text-[#7A7A76] mt-2">Distributed upon finality</div>
            </div>

            {/* Commitment Certificate */}
            <div className="pt-6 border-t border-[#333336]">
              <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest mb-3">Settlement Certificate</div>
              <div className="space-y-2 text-[10px]">
                <div className="flex justify-between">
                  <span className="text-[#7A7A76]">Block Height</span>
                  <span className="text-[#9A9A96] font-mono">—</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#7A7A76]">Tx Hash</span>
                  <span className="text-[#9A9A96] font-mono">—</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#7A7A76]">Timestamp</span>
                  <span className="text-[#9A9A96] font-mono">Awaiting</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onNavigate('market')}
              className="w-full bg-[#2A2A2C] border border-[#8B7355] text-[#8B7355] px-4 py-2.5 text-[10px] uppercase tracking-widest hover:bg-[#8B7355]/10 transition-colors"
            >
              View Market Output
            </button>
          </div>
        </aside>
      </div>

      {/* BOTTOM: Agent Performance Strip */}
      <footer className="border-t border-[#333336] bg-[#242426] px-8 py-4 flex-shrink-0">
        <div className="flex items-center justify-between">
          <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest">Agent Performance</div>
          <div className="flex items-center gap-8 text-[10px]">
            <div className="flex items-center gap-2">
              <span className="text-[#7A7A76]">Translator-01</span>
              <span className="text-[#9A9A96]">42 markets</span>
              <span className="text-[#8B7355]">71% avg</span>
              <span className="text-[#7A9178]">12.4 USDC</span>
            </div>
            <div className="w-px h-4 bg-[#333336]" />
            <div className="flex items-center gap-2">
              <span className="text-[#7A7A76]">Critic-03</span>
              <span className="text-[#9A9A96]">39 markets</span>
              <span className="text-[#8B7355]">84% avg</span>
              <span className="text-[#7A9178]">9.8 USDC</span>
            </div>
            <div className="w-px h-4 bg-[#333336]" />
            <div className="flex items-center gap-2">
              <span className="text-[#7A7A76]">MarketGen-02</span>
              <span className="text-[#9A9A96]">34 markets</span>
              <span className="text-[#8B7355]">68% avg</span>
              <span className="text-[#7A9178]">8.1 USDC</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function AgentBlock({
  title,
  status,
  confidence,
  timestamp,
  reasoning,
}: {
  title: string;
  status: 'validated' | 'processing' | 'awaiting';
  confidence: number | null;
  timestamp: string | null;
  reasoning: string;
}) {
  return (
    <div className="border-b border-[#333336] py-6 first:pt-0">
      {/* Agent Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="text-xs text-[#D4D4D0] uppercase tracking-wide">{title}</div>
          {status === 'validated' && (
            <div className="px-2 py-0.5 bg-[#2A2A2C] border border-[#7A9178]/30 text-[#7A9178] text-[9px] uppercase tracking-wider">
              Validated
            </div>
          )}
          {status === 'processing' && (
            <div className="px-2 py-0.5 bg-[#2A2A2C] border border-[#6B8E9F]/30 text-[#6B8E9F] text-[9px] uppercase tracking-wider flex items-center gap-1">
              <span className="w-1 h-1 bg-[#6B8E9F] rounded-full animate-pulse" />
              Processing
            </div>
          )}
          {status === 'awaiting' && (
            <div className="px-2 py-0.5 bg-[#2A2A2C] border border-[#7A7A76]/30 text-[#7A7A76] text-[9px] uppercase tracking-wider">
              Awaiting
            </div>
          )}
        </div>
        <div className="flex items-center gap-4">
          {confidence && (
            <div className="text-[10px] text-[#8B7355] font-mono">{confidence}%</div>
          )}
          {timestamp && (
            <div className="text-[9px] text-[#7A7A76] font-mono">{timestamp}</div>
          )}
        </div>
      </div>

      {/* Reasoning Output */}
      <div className="text-[11px] text-[#9A9A96] leading-relaxed pl-4 border-l-2 border-[#333336]">
        {reasoning}
      </div>
    </div>
  );
}
