export function MarketScreen({ onNavigate }: { onNavigate: (screen: string) => void }) {
  return (
    <div className="w-full h-full bg-[#1A1A1C] text-[#D4D4D0] overflow-hidden flex flex-col">
      {/* Header */}
      <header className="border-b border-[#333336] px-8 py-4 flex-shrink-0">
        <div className="flex items-center justify-between">
          <h1
            className="font-serif text-lg tracking-tight cursor-pointer text-[#B0A090]"
            onClick={() => onNavigate('landing')}
          >
            AgoraBabel
          </h1>
          <div className="flex items-center gap-6 text-[10px] text-[#7A7A76] uppercase tracking-wider">
            <span>Intelligence</span>
            <span>Orchestration</span>
            <span className="text-[#8B7355]">Settlement</span>
          </div>
        </div>
      </header>

      {/* Main */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-6xl mx-auto px-8 py-12">
          {/* Header */}
          <div className="mb-8 flex items-start justify-between">
            <div>
              <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest mb-2">Market Output</div>
              <h2 className="font-serif text-2xl text-[#D4D4D0] tracking-tight">
                Argentina Currency Controls
              </h2>
            </div>
            <div className="px-3 py-1.5 bg-[#2A2A2C] border border-[#7A9178]/30 text-[#7A9178] text-[9px] uppercase tracking-widest">
              Market Accepted
            </div>
          </div>

          <div className="grid grid-cols-[1fr_340px] gap-8">
            <div className="space-y-8">
              {/* Market Question */}
              <div className="bg-[#242426] border border-[#333336] p-8">
                <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest mb-4">Resolution Question</div>
                <h3 className="font-serif text-xl text-[#D4D4D0] mb-8 leading-relaxed">
                  Will Argentina officially remove currency controls before July 1, 2026?
                </h3>

                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest">Resolution Source</div>
                    <div className="text-[11px] text-[#9A9A96] leading-relaxed">
                      Official government decree or central bank publication
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest">Deadline</div>
                    <div className="text-[11px] text-[#9A9A96]">July 1, 2026 00:00 UTC</div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest">Category</div>
                    <div className="text-[11px] text-[#9A9A96]">Macro / Argentina / FX Controls</div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest">Confidence</div>
                    <div className="text-[11px] text-[#8B7355] font-mono">63%</div>
                  </div>
                </div>

                <div className="mt-6 pt-6 border-t border-[#333336]">
                  <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest mb-2">Critic Verdict</div>
                  <div className="text-[11px] text-[#7A9178]">
                    Accepted — Resolution criteria validated. Source objectivity confirmed. Temporal bounds verified.
                  </div>
                </div>
              </div>

              {/* Reasoning Trace Archive */}
              <div className="bg-[#242426] border border-[#333336] p-8">
                <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest mb-6">Reasoning Trace Archive</div>
                <div className="space-y-6">
                  <TraceNode
                    step="Source Signal"
                    confidence={92}
                    output="Extracted Spanish news article from La Nación. Signal integrity validated. Source credibility: institutional."
                  />
                  <TraceNode
                    step="Translation Synthesis"
                    confidence={88}
                    output="Local-market terminology mapped to standard financial lexicon. Context preserved through semantic translation."
                  />
                  <TraceNode
                    step="Market Framing"
                    confidence={76}
                    output="Binary question synthesized with clear resolution criteria. Deadline anchored to institutional timeline analysis."
                  />
                  <TraceNode
                    step="Critic Validation"
                    confidence={84}
                    output="Ambiguity analysis complete. Resolution source objectivity confirmed. Structural integrity validated."
                  />
                </div>
              </div>

              {/* Agent Performance */}
              <div className="bg-[#242426] border border-[#333336] p-8">
                <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest mb-6">Agent Performance</div>
                <div className="space-y-1">
                  <div className="grid grid-cols-[2fr_1fr_1fr_1fr] gap-4 pb-3 border-b border-[#333336] text-[9px] text-[#7A7A76] uppercase tracking-widest">
                    <div>Agent</div>
                    <div className="text-right">Markets</div>
                    <div className="text-right">Avg Confidence</div>
                    <div className="text-right">Rewards</div>
                  </div>
                  {[
                    { agent: 'Translator-01', markets: 42, confidence: 71, rewards: '12.4' },
                    { agent: 'Critic-03', markets: 39, confidence: 84, rewards: '9.8' },
                    { agent: 'MarketGen-02', markets: 34, confidence: 68, rewards: '8.1' },
                  ].map((row, idx) => (
                    <div
                      key={idx}
                      className="grid grid-cols-[2fr_1fr_1fr_1fr] gap-4 py-3 text-[11px] border-b border-[#333336]/50 last:border-0"
                    >
                      <div className="text-[#D4D4D0]">{row.agent}</div>
                      <div className="text-[#9A9A96] text-right">{row.markets}</div>
                      <div className="text-[#8B7355] text-right font-mono">{row.confidence}%</div>
                      <div className="text-[#7A9178] text-right">{row.rewards} USDC</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column: Settlement Certificate */}
            <div className="space-y-6">
              {/* Arc Receipt */}
              <div className="bg-[#242426] border border-[#8B7355]/20 p-6">
                <div className="text-[9px] text-[#8B7355] uppercase tracking-widest mb-4">Settlement Certificate</div>

                <div className="mb-6 px-3 py-2 bg-[#7A9178]/10 border border-[#7A9178]/20 text-[9px] text-[#7A9178] uppercase tracking-widest text-center">
                  Trace Committed
                </div>

                <div className="space-y-4">
                  <div>
                    <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest mb-2">Transaction Hash</div>
                    <div className="text-[10px] text-[#D4D4D0] font-mono break-all leading-relaxed bg-[#1A1A1C] p-3 border border-[#333336]">
                      0x8273bc4f2a<br/>9e1d6b8c3f7a<br/>5e2d9b6c4a1e<br/>8f3b7c2a9f91a
                    </div>
                  </div>

                  <div className="space-y-2 text-[11px]">
                    <div className="flex justify-between py-2 border-b border-[#333336]/50">
                      <span className="text-[#7A7A76]">Network</span>
                      <span className="text-[#9A9A96]">Arc Testnet</span>
                    </div>
                    <div className="flex justify-between py-2 border-b border-[#333336]/50">
                      <span className="text-[#7A7A76]">Block Height</span>
                      <span className="text-[#9A9A96] font-mono">2,847,391</span>
                    </div>
                    <div className="flex justify-between py-2 border-b border-[#333336]/50">
                      <span className="text-[#7A7A76]">Settlement Fee</span>
                      <span className="text-[#9A9A96]">$0.01 USDC</span>
                    </div>
                    <div className="flex justify-between py-2">
                      <span className="text-[#7A7A76]">Timestamp</span>
                      <span className="text-[#9A9A96] font-mono">2026-05-15 14:23:17</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Trace Hash */}
              <div className="bg-[#242426] border border-[#333336] p-6">
                <div className="text-[9px] text-[#7A7A76] uppercase tracking-widest mb-4">Reasoning Trace Hash</div>
                <div className="text-[10px] text-[#D4D4D0] font-mono break-all leading-relaxed bg-[#1A1A1C] p-3 border border-[#333336]">
                  0x9f2a8c1b4e7d<br/>3a5f6c9e2b8d<br/>7f4a1c6e9b3d<br/>2a8f5c1e7b81bd
                </div>
              </div>

              {/* Reward Pool */}
              <div className="bg-[#2A2A2C] border border-[#8B7355]/30 p-6">
                <div className="text-[9px] text-[#8B7355] uppercase tracking-widest mb-3">Reward Distribution</div>
                <div className="flex items-baseline gap-2 mb-2">
                  <span className="text-3xl font-serif text-[#D4D4D0]">1.25</span>
                  <span className="text-xs text-[#7A7A76]">USDC</span>
                </div>
                <div className="text-[9px] text-[#7A7A76]">Distributed to contributing agents</div>
              </div>

              <button
                onClick={() => onNavigate('landing')}
                className="w-full bg-[#2A2A2C] border border-[#333336] text-[#9A9A96] px-4 py-2.5 text-[10px] uppercase tracking-widest hover:border-[#8B7355] hover:text-[#8B7355] transition-colors"
              >
                Return to Input
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function TraceNode({
  step,
  confidence,
  output,
}: {
  step: string;
  confidence: number;
  output: string;
}) {
  return (
    <div className="border-l-2 border-[#333336] pl-6">
      <div className="flex items-center justify-between mb-2">
        <div className="text-xs text-[#D4D4D0] uppercase tracking-wide">{step}</div>
        <div className="text-[10px] text-[#8B7355] font-mono">{confidence}%</div>
      </div>
      <div className="text-[11px] text-[#9A9A96] leading-relaxed">{output}</div>
    </div>
  );
}
