
  # AgoraBabel SaaS Prototype

  This is a code bundle for AgoraBabel SaaS Prototype. The original project is available at https://www.figma.com/design/Ni74UVr1wfkME7ekK6youJ/AgoraBabel-SaaS-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  